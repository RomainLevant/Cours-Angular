var a = 10;

for (let b=0; b<5; b++)
{
    console.log( b );
    console.log( a );
    console.log('===');
}


console.log( a );
console.log( b );
